## ---- include = FALSE---------------------------------------------------------

knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>")


## ----setup--------------------------------------------------------------------

library(pscore)


## ---- eval = FALSE------------------------------------------------------------
#  ## install devtools package, to get other packages from GitHub
#  install.packages("devtools")
#  
#  ## this is the workhorse with the functions to do the calculations
#  devtools::install_github("JWiley/score-project/pscore")

## ---- eval = FALSE------------------------------------------------------------
#  ## load data
#  d <- read.csv("sample_metsss.csv")
#  
#  ## only if having trouble, can check the STRucture of the data, which should be similar:
#  str(d)
#  
#  ## use the MetSSS calculator to score the data
#  dscored <- MetSSS(d)
#  
#  ## save the scored data back to another CSV file
#  write.csv(dscored, file = "scored_metsss.csv", row.names = FALSE)

