library(testthat)
library(pscore)

test_check("pscore")
